from __future__ import annotations
from dataclasses import dataclass
from .completion import LegacyShareGapCompletionPolicy, EconomicResponsibilityCompletionPolicy
from .ownership import LegacyExistingThesisOnlyPolicy, RecoverablePreSafeOwnershipPolicy
from .handoff import LegacyAlwaysAllowActiveHandoffPolicy, RecoverabilityActiveHandoffPolicy
from .generation import LegacyRecursiveGenerationPolicy, SingleResponsibilityGenerationPolicy

@dataclass
class ModularPolicyProfile:
    name: str
    completion: object
    ownership: object
    handoff: object
    generation: object

    def describe(self):
        return {
            'profile': self.name,
            'completion': getattr(self.completion,'name',type(self.completion).__name__),
            'ownership': getattr(self.ownership,'name',type(self.ownership).__name__),
            'handoff': getattr(self.handoff,'name',type(self.handoff).__name__),
            'generation': getattr(self.generation,'name',type(self.generation).__name__),
        }

def legacy_v76_profile() -> ModularPolicyProfile:
    # Research-control profile: preserves pre-V75/V76 semantics by keeping legacy ownership/handoff.
    return ModularPolicyProfile(
        name='LEGACY_RESEARCH_CONTROL_V1',
        completion=LegacyShareGapCompletionPolicy(),
        ownership=LegacyExistingThesisOnlyPolicy(),
        handoff=LegacyAlwaysAllowActiveHandoffPolicy(),
        generation=LegacyRecursiveGenerationPolicy(),
    )

def economic_v1_profile() -> ModularPolicyProfile:
    # Authoritative candidate profile. Frozen thresholds are inherited from already-tested V75/V76 logic.
    return ModularPolicyProfile(
        name='ECONOMIC_MANAGEMENT_V1',
        completion=EconomicResponsibilityCompletionPolicy(),
        ownership=RecoverablePreSafeOwnershipPolicy(),
        handoff=RecoverabilityActiveHandoffPolicy(),
        generation=SingleResponsibilityGenerationPolicy(),
    )
