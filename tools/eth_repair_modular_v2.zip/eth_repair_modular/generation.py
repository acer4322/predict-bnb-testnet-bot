from __future__ import annotations
from .contracts import GenerationContext, GenerationDecision, EPS

class LegacyRecursiveGenerationPolicy:
    name = 'legacy_recursive_generation_v70f'
    def evaluate(self, ctx: GenerationContext) -> GenerationDecision:
        return GenerationDecision(True, True, 'LEGACY_RECURSIVE_AUTHORITY')

class SingleResponsibilityGenerationPolicy:
    name = 'single_responsibility_per_generation_v70g'
    def evaluate(self, ctx: GenerationContext) -> GenerationDecision:
        if not ctx.generation_authorized:
            return GenerationDecision(True, ctx.responsibility_count <= 0, 'GENERATION_OPEN')
        unlocked = ctx.debt_increment > EPS and (ctx.debt_increment - ctx.paid_increment) <= EPS
        if unlocked:
            return GenerationDecision(True, True, 'PRIOR_GENERATION_DEBT_DISCHARGED')
        return GenerationDecision(False, False, 'PRIOR_GENERATION_STILL_OWNED')
