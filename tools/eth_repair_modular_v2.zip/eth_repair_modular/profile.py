from __future__ import annotations
from dataclasses import dataclass
from .completion import LegacyShareGapCompletionPolicy, EconomicResponsibilityCompletionPolicy
from .ownership import LegacyExistingThesisOnlyPolicy, RecoverablePreSafeOwnershipPolicy
from .handoff import LegacyAlwaysAllowActiveHandoffPolicy, RecoverabilityActiveHandoffPolicy
from .generation import LegacyRecursiveGenerationPolicy, SingleResponsibilityGenerationPolicy
from .repair_execution import LegacyV36RepairExecutionPolicy, RecursiveCompositeRepairExecutionPolicy

@dataclass
class ModularPolicyProfile:
    name: str
    completion: object
    ownership: object
    handoff: object
    generation: object
    repair_execution: object | None = None

    def describe(self):
        out = {
            'profile': self.name,
            'completion': getattr(self.completion,'name',type(self.completion).__name__),
            'ownership': getattr(self.ownership,'name',type(self.ownership).__name__),
            'handoff': getattr(self.handoff,'name',type(self.handoff).__name__),
            'generation': getattr(self.generation,'name',type(self.generation).__name__),
        }
        if self.repair_execution is not None:
            out['repairExecution'] = getattr(self.repair_execution,'name',type(self.repair_execution).__name__)
        return out

def legacy_v76_profile() -> ModularPolicyProfile:
    # Research-control profile: preserves pre-V75/V76 semantics by keeping legacy ownership/handoff.
    return ModularPolicyProfile(
        name='LEGACY_RESEARCH_CONTROL_V1',
        completion=LegacyShareGapCompletionPolicy(),
        ownership=LegacyExistingThesisOnlyPolicy(),
        handoff=LegacyAlwaysAllowActiveHandoffPolicy(),
        generation=LegacyRecursiveGenerationPolicy(),
        repair_execution=LegacyV36RepairExecutionPolicy(),
    )

def economic_v1_profile() -> ModularPolicyProfile:
    # Authoritative management profile. Repair execution remains legacy unless explicitly replaced.
    return ModularPolicyProfile(
        name='ECONOMIC_MANAGEMENT_V1',
        completion=EconomicResponsibilityCompletionPolicy(),
        ownership=RecoverablePreSafeOwnershipPolicy(),
        handoff=RecoverabilityActiveHandoffPolicy(),
        generation=SingleResponsibilityGenerationPolicy(),
        repair_execution=LegacyV36RepairExecutionPolicy(),
    )

def economic_recursive_execution_v2_profile() -> ModularPolicyProfile:
    # Same management semantics as ECONOMIC_MANAGEMENT_V1; only the RepairExecutionRouter is replaced.
    return ModularPolicyProfile(
        name='ECONOMIC_MANAGEMENT_RECURSIVE_EXECUTION_V2',
        completion=EconomicResponsibilityCompletionPolicy(),
        ownership=RecoverablePreSafeOwnershipPolicy(),
        handoff=RecoverabilityActiveHandoffPolicy(),
        generation=SingleResponsibilityGenerationPolicy(),
        repair_execution=RecursiveCompositeRepairExecutionPolicy(),
    )
